﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace RestBasicProject.Library
{
    public static class Temp
    {

       
            public static object deserialize(string json)
            {
                return toObject(JToken.Parse(json));
            }

            private static object toObject(JToken token)
            {
                switch (token.Type)
                {
                    case JTokenType.Object:
                        return token.Children<JProperty>()
                                    .ToDictionary(prop => prop.Name,
                                                  prop => toObject(prop.Value));

                    case JTokenType.Array:
                        return token.Select(toObject).ToList();

                    default:
                        return ((JValue)token).Value;
                }
            }
        


    }
}
