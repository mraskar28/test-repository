﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Text;
using System.IO;

namespace RestBasicProject
{
    /// <summary>
    /// This class provides methods for returning records from 
    /// the database
    /// </summary>
    public static class GetRecords
    {

        /// <summary>
        /// This method is used to fetch the record from the database
        /// </summary>
        /// <param name="connection">OleDbConnection</param>
        /// <param name="command">OleDbCommand</param>
        /// <param name="dataAdapter">OleDbDataAdapter</param>
        /// <param name="query">Query</param>
        /// <returns>DataRowCollection</returns>
        public static DataRowCollection GetRecordsFromDatabase(OleDbConnection connection, OleDbCommand command, OleDbDataAdapter dataAdapter, string query)
        {
            //Create SQL Query                        
            command = new OleDbCommand(query, connection);
            //Create data adapter object
            dataAdapter = new OleDbDataAdapter(command);
            DataSet dSet = new DataSet();
            //Fill the data into table 
            dataAdapter.Fill(dSet, "TableCategory");
            //Fetch the rows from the table
            return dSet.Tables["TableCategory"].Rows;
        }

        public static DataSet GetDataSetFromDatabase(OleDbConnection connection, OleDbCommand command, OleDbDataAdapter dataAdapter, string query)
        {
            //Create SQL Query                        
            command = new OleDbCommand(query, connection);
            //Create data adapter object
            dataAdapter = new OleDbDataAdapter(command);
            DataSet dSet = new DataSet();
            //Fill the data into table 
            dataAdapter.Fill(dSet, "TableCategory");
            //Fetch the rows from the table
            return dSet;
        }

        /// <summary>
        /// This method is used to fetch the count fo records
        /// </summary>
        /// <param name="connection">OleDbConnection</param>
        /// <param name="command">OleDbCommand</param>
        /// <param name="dataAdapter">OleDbDataAdapter</param>
        /// <param name="query">Query</param>
        /// <returns>Count of records</returns>
        public static int GetDatabaseRecordsCount(OleDbConnection connection, OleDbCommand command, OleDbDataAdapter dataAdapter, string query)
        {
            int recordCount = 0;
            object[] rowObject = null;

            //Create SQL Query                        
            command = new OleDbCommand(query, connection);
            //Create data adapter object
            dataAdapter = new OleDbDataAdapter(command);
            DataSet dSet = new DataSet();
            //Fill the data into table 
            dataAdapter.Fill(dSet, "TableCategory");

            //Fetch the rows from the table
            foreach (DataRow dataRow in dSet.Tables["TableCategory"].Rows)
            {
                rowObject = dataRow.ItemArray;
                //Verify data has been fetched
                if (rowObject != null)
                {
                    recordCount++;
                }
            }

            return recordCount;
        }
    }
}
