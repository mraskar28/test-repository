﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExcelDataReader;

namespace RestBasicProject.Library
{
    public class ExcelRead
    {
        private static List<DataCollection> _dataCol = new List<DataCollection>();

        /// <summary>
        /// storing all values from excel into in memmory collection
        /// </summary>
        /// <param name="fileName"></param>
        public static void PopulateInCollection(string fileName)
        {
            DataTable table = ExcelToDataTable(fileName);

            //Iterate through rows and column of data table
            for (int row = 1; row <= table.Rows.Count; row++)
            {
                for (int col = 0; col < table.Columns.Count; col++)
                {
                    DataCollection dtTable = new DataCollection()
                    {
                        rownumber = row,
                        colName = table.Columns[col].ColumnName,
                        colValue = table.Rows[row - 1][col].ToString()

                    };
                    //add all deails for each row
                    _dataCol.Add(dtTable);

                }

            }


        }

        public static string ReadData(int rowNumber, string columnName)
        {
            try
            {
                string data = (from colData in _dataCol
                               where colData.rownumber == rowNumber && colData.colName == columnName
                               select colData.colValue).SingleOrDefault();

                //var data = _dataCol.Where(x => x.colName == columnName && x.rownumber == rowNumber).SingleOrDefault().colValue;

                return data.ToString();

            }
            catch (Exception e)
            {
                return null;
            }
        }

        /// <summary>
        /// read from excel sheet into data set
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>

        private static DataTable ExcelToDataTable(string fileName)
        {
            //******************************* old code *********************************
            ////open file and return as stream
            //FileStream stream = File.Open(fileName, FileMode.Open, FileAccess.Read);
            ////creatOpenXmlReader via excel reader factory
            //IExcelDataReader excelReader = ExcelReaderFactory.CreateOpenXmlReader(stream);
            ////below 2 lines are not supported
            ////set first row as column name
            //// excelReader.IsFirstRowAsColunNames = true;
            ////return as data set
            ////DataSet result = excelReader.AsDataSet();
            //var result = excelReader.AsDataSet(new ExcelDataSetConfiguration()
            //{
            //    ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
            //    {
            //        UseHeaderRow = true
            //    }

            //});

            //// get all tables
            //DataTableCollection table = result.Tables;
            ////store in data table
            //DataTable resultTable = table["sheet1"];
            ////return
            //return resultTable;
            //******************************* old code *********************************


            using (var stream = File.Open(fileName, FileMode.Open, FileAccess.Read))

            {
                using (var reader = ExcelReaderFactory.CreateReader(stream))
                {
                    //return as data set

                    var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                    {
                        ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                        {
                            UseHeaderRow = true
                        }

                    });

                    // get all tables
                    DataTableCollection table = result.Tables;
                    //store in data table
                    DataTable resultTable = table["sheet1"];
                    //return
                    return resultTable;


                }

            }


        }

    }


    public class DataCollection
    {
        public int rownumber { get; set; }
        public string colName { get; set; }
        public string colValue { get; set; }


    }
}
