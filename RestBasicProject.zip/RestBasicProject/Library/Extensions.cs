﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Serialization;
using Newtonsoft.Json;

namespace RestBasicProject
{
    public static class Extensions
    {

        #region XML Deserialization        
        /// <summary>
        /// This method is used to deserialize XML response into object
        /// </summary>
        /// <param name="XMLInput">string</param>
        /// <returns>object</returns>
		/// Sandra Test
		public static T DeserializeFromXMLInput<T>(this string XMLInput)
        {
            T result;
            XmlSerializer ser = new XmlSerializer(typeof(T));
            using (StringReader tr = new StringReader(XMLInput))
            {
                result = (T)ser.Deserialize(tr);
            }

            return result;
        }
        #endregion

        #region JSON Deserialization        
        /// <summary>
        /// This method is used to deserialize JSON response into object
        /// We have used NEWTONSOFT.JSON library for deserializing JSON response into the object
        /// </summary>
        /// <param name="JSONInput">string</param>
        /// <returns>object</returns>
		public static T DeserializeFromJSONInput<T>(this string JSONInput)
        {
            return JsonConvert.DeserializeObject<T>(JSONInput);
        }

        /// <summary>
        /// This method is used to deserialize JSON response into list of objects
        /// We have used NEWTONSOFT.JSON library for deserializing JSON response into the object
        /// </summary>
        /// <param name="JSONInput">string</param>
        /// <returns>List of object</returns>
        public static List<T> DeserializeListFromJSONInput<T>(this string JSONInput)
        {
            return JsonConvert.DeserializeObject<List<T>>(JSONInput);
        }

        #endregion
    }
}