﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestBasicProject.RecordDTO.ListTransactionSummary;

namespace RestBasicProject.Library
{
    class Database
    {
        string connectionString = string.Empty;
        static OleDbConnection dbConnection = null;
        static OleDbCommand dbCommand = null;
        static OleDbDataAdapter dbDataAdapter = null;
        static DataRowCollection dbRows = null;
        static object[] rowObject = null;

        public static void OpenConnection(string connection)
        {
            try
            {
                //create object of oledb connection
                //string connection = @"Provider=SQLOLEDB;Data Source=XIPLRAC036\SQLEXPRESS14;Initial Catalog=""Car Finance"";User ID=admin;Password=password";
                dbConnection = new System.Data.OleDb.OleDbConnection(connection);
                //open the oledb connection
                dbConnection.Open();
            }
            catch(Exception e)
            {
                Console.WriteLine("cannot open connection");
            }


        }
        public static void CloseConnection()
        {
            dbConnection.Close();

        }
        public static List<EargastDTO> SelectData(string query)
        {

            dbRows = GetRecords.GetRecordsFromDatabase(dbConnection, dbCommand, dbDataAdapter, query);
            EargastDTO ergast = null;
            List<EargastDTO> ergastList = null;
            ergast = null;
            ergastList = new List<EargastDTO>();
            foreach (DataRow datarow in dbRows)
            {

                rowObject = datarow.ItemArray;
                if (rowObject != null)
                {
                    ergast = new EargastDTO();

                    ergast.CircuitName = rowObject[0].ToString();
                    ergast.Locality = rowObject[1].ToString();
                    ergast.Country = rowObject[2].ToString();

                    ergastList.Add(ergast);
                }
            }
            return ergastList;

        }


        //public static DataRowCollection GetRecordsFromDatabase(OleDbConnection connection, OleDbCommand command, OleDbDataAdapter dataAdapter, string query)
        //{
        //    //Create SQL Query                        
        //    command = new OleDbCommand(query, connection);
        //    //Create data adapter object
        //    dataAdapter = new OleDbDataAdapter(command);
        //    DataSet dSet = new DataSet();
        //    //Fill the data into table 
        //    dataAdapter.Fill(dSet, "TableCategory");
        //    //Fetch the rows from the table
        //    return dSet.Tables["TableCategory"].Rows;
        //}






    }
}
