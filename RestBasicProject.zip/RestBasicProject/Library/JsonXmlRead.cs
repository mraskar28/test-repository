﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using AventStack.ExtentReports.Model;
using static System.Net.Mime.MediaTypeNames;


namespace RestBasicProject.Library
{
    public class JsonXmlRead
    {
        private static string _testDataPath = @"D:\mayur\car finance\RestSharp_POC\xRest-CSharp-POC\xRest-CSharp-POC\xRest-CSharp-POC\RestBasicProject\ResponseDTO";
        /// <summary>
        /// Get the test data directory for the given file.
        /// </summary>
        /// <param name="fileName">Name of the file to read.</param>
        /// <returns>Contents of the test data file provided by the name.</returns>
        public static string GetTestDataDirectory(string folderName, string fileName)
        {
            var output = string.Empty;

            try
            {
                //to get current working directory
                string fullPath = AppDomain.CurrentDomain.BaseDirectory;
                if (fullPath.EndsWith("\\bin\\Debug\\"))
                {
                    fullPath = fullPath.Replace("\\bin\\Debug\\", "");

                }


                fullPath = fullPath + "\\" + folderName + "\\" + fileName;

                //var fullPath = FindFile(new DirectoryInfo(Directory.GetCurrentDirectory()), fileName);
           


                using (var reader = new StreamReader(fullPath))
                {
                    output = reader.ReadToEnd();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("unable to find file");
            }

            return output;
        }

        ///// <summary>
        ///// Find the given file in the given directory.
        ///// </summary>
        ///// <param name="directory">Information about the root directory to look for a given file in.</param>
        ///// <param name="fileName">Name of the file to search for in the given directory.</param>
        ///// <returns>Path to the given file if it exists.</returns>
        //private static string FindFile(DirectoryInfo directory, string fileName)
        //{
        //    foreach (var dir in directory.GetDirectories())
        //    {
        //        foreach (var childDirectories in dir.GetDirectories())
        //        {
        //            var file = FindFileInDirectory(childDirectories, fileName);

        //            if (file != string.Empty)
        //            {
        //                return file;
        //            }
        //            else
        //            {
        //                file = FindFile(childDirectories, fileName);
        //            }
        //        }
        //    }

        //    return string.Empty;
        //}

        ///// <summary>
        ///// Search for a specific file in the given directory.
        ///// </summary>
        ///// <param name="directory">Info about the current directory to find the given file.</param>
        ///// <param name="fileName"></param>
        ///// <returns>String representing the fully qualified path of the file.</returns>
        //private static string FindFileInDirectory(DirectoryInfo directory, string fileName)
        //{
        //    if (directory.FullName.Contains(_testDataPath))
        //    {
        //        foreach (FileInfo file in directory.GetFiles())
        //        {
        //            if (Path.GetFileNameWithoutExtension(file.Name) == fileName)
        //            {
        //                return file.FullName;
        //            }
        //        }
        //    }

        //    return string.Empty;
        //}



    }
}
