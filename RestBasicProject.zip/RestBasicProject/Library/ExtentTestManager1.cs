﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AventStack.ExtentReports;


namespace RestBasicProject.Library
{
    class ExtentTestManager1
    {
        public class ExtentTestManager
        {
            int i = 0;
            //private static ThreadLocal _test;
            //private static ExtentReports _extent = ExtentManager.Instance;

            //public static object ExtentManager { get; private set; }

            //[MethodImpl(MethodImplOptions.Synchronized)]
            //public static ExtentTest GetTest()
            //{
            //    return _test.Value;
            //}

            //[MethodImpl(MethodImplOptions.Synchronized)]
            //public static ExtentTest CreateTest(string name)
            //{
            //    if (_test == null)
            //        _test = new ThreadLocal();

            //    var t = _extent.CreateTest(name);
            //    _test.Value = t;

            //    return t;
            //}
        }

    }
}
