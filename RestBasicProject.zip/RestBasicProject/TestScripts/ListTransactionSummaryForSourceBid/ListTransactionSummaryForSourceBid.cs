﻿using NUnit.Framework;
using RestBasicProject.ResponseDTO;
using RestSharp;
using System.Collections.Generic;
using RestBasicProject.Library;
using RestBasicProject.RecordDTO.ListTransactionSummary;
using AventStack.ExtentReports;
using System;
using RestSharp.Authenticators;
using System.Net.Http;
using RestBasicProject.TestScripts.ListTransactionSummaryForSourceBid;
using System.Configuration;

namespace RestBasicProject
{
    [TestFixture]
    [Authentication]
    class ListTransactionSummaryForSourceBid : BaseClass
    {

        //Get test case
        [Test]
        //[Ignore("my life my choice")]
        public void CarFinanceGet()
        {

            //common variables
            List<RootObject> responseJSON;
            IRestResponse response;
            MRData responseXML;
            //List<CarFinanceDTO> record = null;
            List<EargastDTO> recordErgast = null;
            string connectionString = string.Empty;
            //sql query to be passed
            //string sqlQuery = "select * from CarFinance";

            //extent logging for start of test case
            test = extent.CreateTest("CAR FINANCE GET TEST CASE");

            #region Accept JSON
            //hitting get request using rest client
            var requestJson = new RestRequest(Method.GET);
            client.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url1"]);


            //requestJson.AddParameter("username", "mayur");
            //requestJson.AddParameter("password", "mayur");
            // client.Authenticator = new HttpBasicAuthenticator("mayur", "mayur");



            response = client.Execute(requestJson);
            //deserialize json request
            responseJSON = Extensions.DeserializeFromJSONInput<List<RootObject>>(response.Content);

            //database query fetch
            //Database.OpenConnection(@"Provider=SQLOLEDB;Data Source=XIPLRAC036\SQLEXPRESS14;Initial Catalog=""Car Finance"";User ID=admin;Password=password");
            //record = Database.SelectData(sqlQuery);
            //Database.CloseConnection();


            //try
            //{

            //assertion for list
            //foreach (var res in responseJSON)
            //{
            //    foreach (CarFinanceDTO carFinance in record)
            //    {
            //        if (res.id == carFinance.Id)
            //        {
            //            //verify id
            //            Assert.AreEqual(res.id, carFinance.Id);
            //            test.Log(Status.Pass, "ID " + res.id + " is equal to " + carFinance.Id);
            //            VerificationAssert(res.id, carFinance.Id, "ID");
            //            //verify category
            //            Assert.AreEqual(res.category, carFinance.Category);
            //            test.Log(Status.Pass, "CATEGORY " + res.category + " is equal to " + carFinance.Category);
            //            //verify question
            //            Assert.AreEqual(res.question, carFinance.Question);
            //            test.Log(Status.Pass, "QUESTION " + res.question + " is equal to " + carFinance.Question);
            //            break;
            //        }
            //    }

                //    }
                //}
                //catch (Exception e)
                //{
                //    Console.WriteLine("error occured");
                //    test.Log(Status.Fail, "Exception Occured");
                //}
                #endregion


            #region Accept XML
            //Accept xml part
            var requestXML = new RestRequest(Method.GET);
            requestXML.AddHeader("Accept", "application/xml");
            string sqlFetchErgast = "select * from Ergast";

            //database query fetch
            Database.OpenConnection(@"Provider=SQLOLEDB;Data Source=XIPLRAC036\SQLEXPRESS14;Initial Catalog=""Car Finance"";User ID=admin;Password=password");
            recordErgast = Database.SelectData(sqlFetchErgast);
            Database.CloseConnection();

            client.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url2"]);

            //hit and deserialize xml request
            response = client.Execute(requestXML);
            responseXML = Extensions.DeserializeFromXMLInput<MRData>(response.Content);


            //assertion for response
            foreach (var circuit in responseXML.CircuitTable.Circuit)
            {
                //assertion for table
                foreach (EargastDTO res in recordErgast)
                {
                    if (res.CircuitName == circuit.CircuitName)
                    {
                        //verify circuit name
                        Assert.AreEqual(res.CircuitName, circuit.CircuitName);
                        test.Log(Status.Pass, "ID " + res.CircuitName + " is equal to " + circuit.CircuitName);

                        //verify locality
                        Assert.AreEqual(res.Locality, circuit.Location.Locality);
                        test.Log(Status.Pass, "locality " + res.Locality + " is equal to " + circuit.Location.Locality);

                        //verify country
                        Assert.AreEqual(res.Country, circuit.Location.Country);
                        test.Log(Status.Pass, "country " + res.Country + " is equal to " + circuit.Location.Country);

                    }


                }



            }





            #endregion





        }

       
        
        [Test]
        public void CarFinancePOST()
        {

            RootObject1 responseJSON;
            IRestResponse response;
            //create test
            test = extent.CreateTest("CAR FINANCE POST TEST CASE");

            #region content JSON
            //    Setup Request JSON
            var requestJson = new RestRequest(Method.POST);
            requestJson.RequestFormat = DataFormat.Json;
            //fetch json body from json file
            string body = JsonXmlRead.GetTestDataDirectory("ResponseDTO", "JsonBody.json");
            //adding parameters
            requestJson.AddHeader("Accept", "application/json");
            requestJson.Parameters.Clear();
            requestJson.AddParameter("application/json", body, ParameterType.RequestBody);
            //hit and deserialize request
            client.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url3"]);
            response = client.Execute(requestJson);

            responseJSON = Extensions.DeserializeFromJSONInput<RootObject1>(response.Content);
            //assertion
            //Assert.AreEqual(responseJSON.origenateAppNumber, 113357);
            test.Log(Status.Pass, "content json checkpoint passed");
            #endregion
            
            #region content XML
            var requestXml = new RestRequest(Method.POST);
            requestXml.RequestFormat = DataFormat.Xml;

            //fetch xml body from excel sheet
            ExcelRead.PopulateInCollection(@"D:\mayur\car finance\RestSharp_POC\carFinanceTestData.xlsx");
            //string xmlBody = ExcelRead.ReadData(1, "xmlBody");
            string xmlBody = JsonXmlRead.GetTestDataDirectory("ResponseDTO", "XmlBody.xml");
            //adding parameters
            requestXml.AddHeader("Accept", "application/xml");
            requestXml.Parameters.Clear();
            requestXml.AddParameter("text/xml", xmlBody, ParameterType.RequestBody);
            //execute request
            client.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url4"]);
            response = client.Execute(requestXml);
            //deserialize response
            Envelope responseXML = Extensions.DeserializeFromXMLInput<Envelope>(response.Content);
            //assertion
            Assert.AreEqual(responseXML.Body.FahrenheitToCelsiusResponse.FahrenheitToCelsiusResult, "37.7777777777778");
            test.Log(Status.Pass, "content xml checkpoint passed");
            #endregion

        }









        //[Test]
        //public void CarFinanceGet1()
        //{

        //    List<RootObject> responseJSON;
        //    IRestResponse response;
        //    MRData responseXML;
        //    List<CarFinanceDTO> record = null;
        //    string connectionString = string.Empty;
        //    string sqlQuery = "select * from CarFinance";


        //    test = extent.CreateTest("CAR FINANCE GET1 TEST CASE");
        //    #region Accept JSON
        //    //Setup Request JSON
        //    var requestJson = new RestRequest(Method.GET);
        //    response = client.Execute(requestJson);
        //    //deserialize json request
        //    responseJSON = Extensions.DeserializeFromJSONInput<List<RootObject>>(response.Content);

        //    //database query fetch
        //    Database.OpenConnection(@"Provider=SQLOLEDB;Data Source=XIPLRAC036\SQLEXPRESS14;Initial Catalog=""Car Finance"";User ID=admin;Password=password");
        //    record = Database.SelectData(sqlQuery);
        //    Database.CloseConnection();


        //    try
        //    {

        //        //assertion for list
        //        foreach (var res in responseJSON)
        //        {
        //            foreach (CarFinanceDTO carFinance in record)
        //            {
        //                if (res.id == carFinance.Id)
        //                {
        //                    //verify id
        //                    Assert.AreEqual(res.id, carFinance.Id);
        //                    test.Log(Status.Pass, "ID " + res.id + " is equal to " + carFinance.Id);
        //                    //verify category
        //                    Assert.AreEqual(res.category, carFinance.Category);
        //                    test.Log(Status.Pass, "CATEGORY " + res.category + " is equal to " + carFinance.Category);
        //                    //verify question
        //                    //Assert.AreEqual(res.question, carFinance.Question);
        //                    Assert.AreEqual(res.question, "2");
        //                    test.Log(Status.Pass, "QUESTION " + res.question + " is equal to " + carFinance.Question);
        //                    break;
        //                }
        //            }

        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        Console.WriteLine("error occured");
        //        test.Log(Status.Fail, "Exception Occured");
        //    }
        //    #endregion

        //    #region Accept XML
        //    //hit request for accept xml
        //    var requestXML = new RestRequest(Method.GET);
        //    requestXML.AddHeader("Accept", "application/xml");

        //    //hit and deserialize request
        //    response = client1.Execute(requestXML);
        //    responseXML = Extensions.DeserializeFromXMLInput<MRData>(response.Content);
        //    test.Log(Status.Pass, "get test case accept xml part passed");
        //    #endregion
        //}



    }
}