﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace RestBasicProject.TestScripts.ListTransactionSummaryForSourceBid
{
    public class Prameterization
    {

        [Test]
        [TestCase(123,"Hi", ExpectedResult = "H")]
        [TestCase(456, "Hello", ExpectedResult = "Hello")]
        [TestCase(789, "Hello1", ExpectedResult = "Hello1")]
        public string Parameter(int param1,string param2)
        {
            int x = param1;
            string temp = param2;
            Console.WriteLine(x);
            Console.WriteLine(temp);


            return temp;
        }

        //take data from common test data class commonTestData.cs
        [Test]
        [TestCaseSource(typeof(CommonTestData), "TestCases")]
        public string Parameter1(int param1, string param2)
        {
            int x = param1;
            string temp = param2;
            Console.WriteLine(x);
            Console.WriteLine(temp);

            return temp;
           
        }


        //VALUES
        [Test]
        public void Parameter3(
         [Values(123,456)]int param1, 
         [Values("hi", "hello")] string param2)
        {
            int x = param1;
            string temp = param2;
            Console.WriteLine(x);
            Console.WriteLine(temp);


            
        }

        //values  +sequantial
        [Test]
        [Sequential]
        public void Parameter4(
        [Values(123, 456)]int param1,
        [Values("hi", "hello")] string param2)
        {
            int x = param1;
            string temp = param2;
            Console.WriteLine(x);
            Console.WriteLine(temp);



        }









        ///TEXT FILE
        ////***************************take code form plural site lecture 6 and implement*******************************
        ////take data form text file
        //public void Parameter2(int param1, string param2)
        //{
        //    int x = param1;
        //    string temp = param2;
        //    Console.WriteLine(x);
        //    Console.WriteLine(temp);
        //    //***************************take code form plural site lecture 6 and implement*******************************


        //}




    }
}
