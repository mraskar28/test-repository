﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace RestBasicProject.TestScripts.ListTransactionSummaryForSourceBid
{
    public class CommonTestData
    {

        public static IEnumerable TestCases
        {
            get
            {
                yield return new TestCaseData(123, "Hi").Returns("H");
                yield return new TestCaseData(456, "Hello").Returns("Hello");
                yield return new TestCaseData(789, "Hello1").Returns("Hello1");

            }




        }







    }
}
