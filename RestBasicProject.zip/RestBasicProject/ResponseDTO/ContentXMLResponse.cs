﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RestBasicProject.ResponseDTO
{
    [XmlRoot(ElementName = "FahrenheitToCelsiusResponse", Namespace = "https://www.w3schools.com/xml/")]
    public class FahrenheitToCelsiusResponse
    {
        [XmlElement(ElementName = "FahrenheitToCelsiusResult", Namespace = "https://www.w3schools.com/xml/")]
        public string FahrenheitToCelsiusResult { get; set; }
        [XmlAttribute(AttributeName = "xmlns")]
        public string Xmlns { get; set; }
    }

    [XmlRoot(ElementName = "Body", Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    public class Body
    {
        [XmlElement(ElementName = "FahrenheitToCelsiusResponse", Namespace = "https://www.w3schools.com/xml/")]
        public FahrenheitToCelsiusResponse FahrenheitToCelsiusResponse { get; set; }
    }

    [XmlRoot(ElementName = "Envelope", Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
    public class Envelope
    {
        [XmlElement(ElementName = "Body", Namespace = "http://schemas.xmlsoap.org/soap/envelope/")]
        public Body Body { get; set; }
        [XmlAttribute(AttributeName = "soap", Namespace = "http://www.w3.org/2000/xmlns/")]
        public string Soap { get; set; }
        [XmlAttribute(AttributeName = "xsi", Namespace = "http://www.w3.org/2000/xmlns/")]
        public string Xsi { get; set; }
        [XmlAttribute(AttributeName = "xsd", Namespace = "http://www.w3.org/2000/xmlns/")]
        public string Xsd { get; set; }
    }
}
