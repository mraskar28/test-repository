﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBasicProject.ResponseDTO
{
    public class RootObject
    {
        public string id { get; set; }
        public string category { get; set; }
        public string question { get; set; }
        public string answer { get; set; }
        public int lenderOfRecordId { get; set; }
    }


}
