﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBasicProject.ResponseDTO
{
    class CarFinancePostBody
    {
        public int origenateAppNumber { get; set; }
        public int remoteRefNumber { get; set; }

    }

}
