﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBasicProject.ResponseDTO
{
    public class RootObject1
    {
        public int origenateAppNumber { get; set; }
        public string remoteRefNumber { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public object email { get; set; }
        public int loanId { get; set; }
        public int typeId { get; set; }
        public bool isSuccessfull { get; set; }
        public string errorDescription { get; set; }
        public List<object> validationErrors { get; set; }
    }

}
