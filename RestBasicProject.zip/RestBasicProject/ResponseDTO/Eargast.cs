﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace RestBasicProject.ResponseDTO
{
    [XmlRoot(ElementName = "Location", Namespace = "http://ergast.com/mrd/1.4")]
    public class Location
    {
        [XmlElement(ElementName = "Locality", Namespace = "http://ergast.com/mrd/1.4")]
        public string Locality { get; set; }
        [XmlElement(ElementName = "Country", Namespace = "http://ergast.com/mrd/1.4")]
        public string Country { get; set; }
        [XmlAttribute(AttributeName = "lat")]
        public string Lat { get; set; }
        [XmlAttribute(AttributeName = "long")]
        public string Long { get; set; }
    }

    [XmlRoot(ElementName = "Circuit", Namespace = "http://ergast.com/mrd/1.4")]
    public class Circuit
    {
        [XmlElement(ElementName = "CircuitName", Namespace = "http://ergast.com/mrd/1.4")]
        public string CircuitName { get; set; }
        [XmlElement(ElementName = "Location", Namespace = "http://ergast.com/mrd/1.4")]
        public Location Location { get; set; }
        [XmlAttribute(AttributeName = "circuitId")]
        public string CircuitId { get; set; }
        [XmlAttribute(AttributeName = "url")]
        public string Url { get; set; }
    }

    [XmlRoot(ElementName = "CircuitTable", Namespace = "http://ergast.com/mrd/1.4")]
    public class CircuitTable
    {
        [XmlElement(ElementName = "Circuit", Namespace = "http://ergast.com/mrd/1.4")]
        public List<Circuit> Circuit { get; set; }
        [XmlAttribute(AttributeName = "season")]
        public string Season { get; set; }
    }

    [XmlRoot(ElementName = "MRData", Namespace = "http://ergast.com/mrd/1.4")]
    public class MRData
    {
        [XmlElement(ElementName = "CircuitTable", Namespace = "http://ergast.com/mrd/1.4")]
        public CircuitTable CircuitTable { get; set; }
        [XmlAttribute(AttributeName = "xmlns")]
        public string Xmlns { get; set; }
        [XmlAttribute(AttributeName = "series")]
        public string Series { get; set; }
        [XmlAttribute(AttributeName = "url")]
        public string Url { get; set; }
        [XmlAttribute(AttributeName = "limit")]
        public string Limit { get; set; }
        [XmlAttribute(AttributeName = "offset")]
        public string Offset { get; set; }
        [XmlAttribute(AttributeName = "total")]
        public string Total { get; set; }
    }

}
