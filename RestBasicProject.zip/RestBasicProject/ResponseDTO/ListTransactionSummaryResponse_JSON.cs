﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RestBasicProject
{
    public class Customer2
    {
        public string mstrCustId { get; set; }
        public string jobCustAcctId { get; set; }
        public string jobCustId { get; set; }
        public string jobCustName { get; set; }
        public string mainCusAcctId { get; set; }
        public string mainCustId { get; set; }
        public string mainCustName { get; set; }
        public string srcCustPO { get; set; }
        public string srcJobName { get; set; }
        public string srcRepName { get; set; }
        public string totalBid { get; set; }
        public string totalInv { get; set; }
        public string totalVar { get; set; }
        public string openOnBid { get; set; }
        public string openNotBid { get; set; }
        public string invOnBid { get; set; }
        public string invNotBid { get; set; }
    }

    public class CustomerJson
    {
        public Customer2 Customer { get; set; }
    }

    public class ListTransactionSummaryResponseJSON
    {
        public bool isError { get; set; }
        public List<CustomerJson> Customer { get; set; }
    }

    public class RootObject
    {
        public ListTransactionSummaryResponseJSON listTransactionSummaryResponse { get; set; }
    }
}