﻿using System;
using System.Xml.Serialization;
using System.Collections.Generic;
namespace RestBasicProject
{
    [XmlRoot(ElementName = "transactionSummaryVO")]
    public class Customer
    {
        [XmlAttribute(AttributeName = "mstrCustId")]
        public string MstrCustId { get; set; }
        [XmlAttribute(AttributeName = "jobCustAcctId")]
        public string JobCustAcctId { get; set; }
        [XmlAttribute(AttributeName = "jobCustId")]
        public string JobCustId { get; set; }
        [XmlAttribute(AttributeName = "jobCustName")]
        public string JobCustName { get; set; }
        [XmlAttribute(AttributeName = "mainCusAcctId")]
        public string MainCusAcctId { get; set; }
        [XmlAttribute(AttributeName = "mainCustId")]
        public string MainCustId { get; set; }
        [XmlAttribute(AttributeName = "mainCustName")]
        public string MainCustName { get; set; }
        [XmlAttribute(AttributeName = "srcCustPO")]
        public string SrcCustPO { get; set; }
        [XmlAttribute(AttributeName = "srcJobName")]
        public string SrcJobName { get; set; }
        [XmlAttribute(AttributeName = "srcRepName")]
        public string SrcRepName { get; set; }
        [XmlAttribute(AttributeName = "totalBid")]
        public string TotalBid { get; set; }
        [XmlAttribute(AttributeName = "totalInv")]
        public string TotalInv { get; set; }
        [XmlAttribute(AttributeName = "totalVar")]
        public string TotalVar { get; set; }
        [XmlAttribute(AttributeName = "openOnBid")]
        public string OpenOnBid { get; set; }
        [XmlAttribute(AttributeName = "openNotBid")]
        public string OpenNotBid { get; set; }
        [XmlAttribute(AttributeName = "invOnBid")]
        public string InvOnBid { get; set; }
        [XmlAttribute(AttributeName = "invNotBid")]
        public string InvNotBid { get; set; }
    }

    [XmlRoot(ElementName = "listTransactionSummaryResponse")]
    public class ListTransactionSummaryResponse
    {
        [XmlElement(ElementName = "customer")]
        public Customer Customer { get; set; }
        [XmlAttribute(AttributeName = "isError")]
        public string IsError { get; set; }

    }
}