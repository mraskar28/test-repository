﻿using System;
using System.Collections.Generic;

namespace RestBasicProject
{
    public class ListTransactionSummaryDTO
    {
        public string MstrCustId { get; set; }
        public string CustAcctId { get; set; }
        public string CustId { get; set; }
        public string JobCustName { get; set; }
        public string MainCusAcctId { get; set; }
        public string MainCustId { get; set; }
        public string MainCustName { get; set; }
        public string srcCustPO { get; set; }
        public string srcJobName { get; set; }
        public string srcRepName { get; set; }
        public string TotalBid { get; set; }
        public string TotalInv { get; set; }
        public string TotalVar { get; set; }
        public string OpenOnBid { get; set; }
        public string OpenNotBid { get; set; }
        public string InvOnBid { get; set; }
        public string InvNotBid { get; set; }
    }
}