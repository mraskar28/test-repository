﻿using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using RestSharp;
using System;
using System.Configuration;

namespace RestBasicProject
{
    /// <summary>
    /// This Class will work as base class for all other classes
    /// </summary>
    public class BaseClass
    {

        public static ExtentReports extent;
        public static ExtentTest test;

        /// <summary>
        /// This variable uses as Rest Client
        /// </summary>
        public RestClient client;
        //public RestClient client1;
        //public RestClient client2;
        //public RestClient client3;

        //public RestClient clientTemp;



        //one time setup
        [OneTimeSetUp]
        public void OneTimeSetup()
        {
            {
                extent = new ExtentReports();
                string reportPath = @"D:\mayur\car finance\RestSharp_POC\Report\TestRunReport.html";
                var htmlReporter = new ExtentHtmlReporter(reportPath);
                extent.AttachReporter(htmlReporter);
            }
        }


        /// <summary>
        /// This is Test Initialization method calls before every test gets started
        /// Setting Client and URL with deserialization handler for JSON type
        /// </summary>
        [SetUp]
        public void TestInitialize()
        {
            //Defining clients 
            client = new RestClient();
            //client = new RestClient();
            //client1 = new RestClient();
            //client2 = new RestClient();
            //client3 = new RestClient();
            //get request 
            //url's are read from configuration files App1.config
            client.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url1"]);

            ////accept xml
            //client1.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url2"]);
            ////post request. content :json
            //client2.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url3"]);
           
            ////content : xml
            //client3.BaseUrl = new System.Uri(ConfigurationManager.AppSettings["url4"]);
          
        }

        [TearDown]
        public void TearDown()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            var stackTrace = "<pre>" + TestContext.CurrentContext.Result.StackTrace + "</pre>";
            var errorMessage = TestContext.CurrentContext.Result.Message;

            if (status == NUnit.Framework.Interfaces.TestStatus.Failed)
            {
                test.Log(Status.Fail, stackTrace + errorMessage);

            }

        }
        [OneTimeTearDown]
        public void OnetimeTearDown()
        {
            extent.Flush();


        }

        /// <summary>
        /// Handles response values that may be returned as null
        /// </summary>
        /// <param name="responseValue"></param>
        /// <param name="dbValue"></param>
        /// <param name="message"></param>
        public void VerificationAssert(string dbValue, string responseValue, string message)
        {
            //Validation of non-empty values
            if (responseValue != null && dbValue != " " && dbValue != "null")
            {
                Assert.AreEqual(dbValue, responseValue, message);
            }

            //Validation when both values are empty
            else if (responseValue == null && (dbValue == " " || dbValue == ""))
            {
                Assert.AreEqual("", "", message);
            }

            //validation when response value is not null and dbvalue is empty or null
            else if (responseValue != null && (dbValue == " " || dbValue == "null" || dbValue == ""))

            {
                Assert.AreEqual(dbValue, responseValue, message);
            }

            //validation when response value is null and dbvalue is not empty
            else if (responseValue == null && dbValue != " ")
            {
                Assert.AreEqual(dbValue, "", message);
            }

            //skipping the verification
            else
            {
                Assert.AreEqual(true, false, message);
            }

        }
    }
}
