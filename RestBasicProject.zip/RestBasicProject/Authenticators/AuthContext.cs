﻿namespace RestBasicProject.Authenticators
{
    /// <summary>
    /// This class set context and passes through application of any authentication tyope
    /// </summary>
    public class AuthContext
    {
    }
}
